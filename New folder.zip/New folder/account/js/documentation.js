<HTML>
<!-- Created by HTTrack Website Copier/3.49-2 [XR&CO'2014] -->

<!-- Mirrored from www.urbanui.com/bogy/template/js/documentation.js by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Feb 2019 01:54:34 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html;charset=UTF-8"><META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://www.urbanui.com/"><TITLE>Page has moved</TITLE>
</HEAD>
<BODY>
<A HREF="http://www.urbanui.com/"><h3>Click here...</h3></A>
</BODY>
<!-- Created by HTTrack Website Copier/3.49-2 [XR&CO'2014] -->

<!-- Mirrored from www.urbanui.com/bogy/template/js/documentation.js by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Feb 2019 01:54:34 GMT -->
</HTML>
